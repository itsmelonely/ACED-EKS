#!/bin/bash
terraform destroy -auto-approve -var-file="var.tfvars"
